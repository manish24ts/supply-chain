import hashlib
import json
import time
from typing import List, Dict

class Block:
    def __init__(self, index: int, timestamp: float, product_data: Dict, previous_hash: str):
        self.index = index
        self.timestamp = timestamp
        self.product_data = product_data
        self.previous_hash = previous_hash
        self.hash = self.calculate_hash()

    def calculate_hash(self) -> str:
        block_string = json.dumps({
            "index": self.index,
            "timestamp": self.timestamp,
            "product_data": self.product_data,
            "previous_hash": self.previous_hash
        }, sort_keys=True).encode()
        return hashlib.sha256(block_string).hexdigest()

class ProductBlockchain:
    def __init__(self):
        self.chain = [self.create_genesis_block()]

    def create_genesis_block(self) -> Block:
        return Block(0, time.time(), {"message": "Genesis Block"}, "0")

    def get_latest_block(self) -> Block:
        return self.chain[-1]

    def add_product(self, product_data: Dict) -> Block:
        previous_block = self.get_latest_block()
        new_block = Block(
            previous_block.index + 1,
            time.time(),
            product_data,
            previous_block.hash
        )
        self.chain.append(new_block)
        return new_block

    def verify_product(self, product_id: str) -> Dict:
        for block in self.chain:
            if 'product_id' in block.product_data and block.product_data['product_id'] == product_id:
                return {
                    "found": True,
                    "product_data": block.product_data,
                    "timestamp": block.timestamp,
                    "block_hash": block.hash
                }
        return {"found": False}

    def is_chain_valid(self) -> bool:
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i-1]

            if current_block.hash != current_block.calculate_hash():
                return False

            if current_block.previous_hash != previous_block.hash:
                return False

        return True

# Example usage function
def demonstrate_system():
    # Initialize the blockchain
    blockchain = ProductBlockchain()

    # Add some sample products
    sample_products = [
        {
            "product_id": "NIKE-AF1-001",
            "name": "Nike Air Force 1",
            "manufacturer": "Nike",
            "manufacturing_date": "2024-01-15",
            "batch_number": "AF1-2024-001",
            "serial_number": "SN12345"
        },
        {
            "product_id": "ADIDAS-UB-001",
            "name": "Adidas Ultraboost",
            "manufacturer": "Adidas",
            "manufacturing_date": "2024-01-16",
            "batch_number": "UB-2024-001",
            "serial_number": "SN67890"
        }
    ]

    # Add products to blockchain
    for product in sample_products:
        blockchain.add_product(product)
        print(f"Added product: {product['name']}")

    # Verify a product
    product_id = "NIKE-AF1-001"
    verification_result = blockchain.verify_product(product_id)
    
    if verification_result["found"]:
        print("\nProduct Verification Successful!")
        print(f"Product Details:")
        print(json.dumps(verification_result["product_data"], indent=2))
    else:
        print("\nProduct Not Found - Potential Counterfeit")

    # Verify chain integrity
    print(f"\nBlockchain Validity: {blockchain.is_chain_valid()}")

if __name__ == "__main__":
    demonstrate_system()