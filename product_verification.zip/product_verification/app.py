# app.py
from flask import Flask, render_template, request, jsonify, flash, redirect, url_for
from blockchain_system import ProductBlockchain
import json

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Required for flash messages

# Initialize blockchain
blockchain = ProductBlockchain()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register_product():
    if request.method == 'POST':
        product_data = {
            "product_id": request.form['product_id'],
            "name": request.form['name'],
            "manufacturer": request.form['manufacturer'],
            "manufacturing_date": request.form['manufacturing_date'],
            "batch_number": request.form['batch_number'],
            "serial_number": request.form['serial_number']
        }
        
        blockchain.add_product(product_data)
        flash('Product registered successfully!', 'success')
        return redirect(url_for('register_product'))
    
    return render_template('register.html')

@app.route('/verify', methods=['GET', 'POST'])
def verify_product():
    if request.method == 'POST':
        product_id = request.form['product_id']
        result = blockchain.verify_product(product_id)
        return render_template('verify.html', result=result)
    
    return render_template('verify.html', result=None)

@app.route('/chain')
def view_chain():
    chain_data = []
    for block in blockchain.chain:
        chain_data.append({
            'index': block.index,
            'timestamp': block.timestamp,
            'product_data': block.product_data,
            'hash': block.hash,
            'previous_hash': block.previous_hash
        })
    return render_template('chain.html', chain=chain_data)

if __name__ == '__main__':
    app.run(debug=True)